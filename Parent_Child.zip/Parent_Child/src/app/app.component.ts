import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ParentComponent } from './parent/parent.component';
import { UerFormComponent } from './uer-form/uer-form.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,ParentComponent,UerFormComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Parent_Child';
}
