import { Component } from '@angular/core';
import { FormControl, Validators, ReactiveFormsModule } from '@angular/forms';

import { ChildComponent } from '../child/child.component';

@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [ReactiveFormsModule, ChildComponent],
  templateUrl: './parent.component.html'
})
export class ParentComponent {

  nameControl = new FormControl('', [
    Validators.required,
    Validators.minLength(3),
    Validators.maxLength(10)
  ]);

 submit() {
  if (this.nameControl.invalid) {
    this.nameControl.markAsTouched();
    return;
  }

  console.log(this.nameControl.value);
}
}
