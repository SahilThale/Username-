import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UerFormComponent } from './uer-form.component';

describe('UerFormComponent', () => {
  let component: UerFormComponent;
  let fixture: ComponentFixture<UerFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UerFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UerFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
