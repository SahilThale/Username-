import { Component } from '@angular/core';
import { TextBoxComponent } from '../ChildComponent/text-box/text-box.component';
import { DropDownComponent } from '../ChildComponent/drop-down/drop-down.component';
import { DatePickerComponent } from '../ChildComponent/date-picker/date-picker.component';
import { ButtonComponent } from '../ChildComponent/button/button.component';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [TextBoxComponent,DropDownComponent,DatePickerComponent,ButtonComponent,ReactiveFormsModule,NgIf,NgFor],
  templateUrl: './uer-form.component.html',
  styleUrl: './uer-form.component.css'
})
export class UerFormComponent {
userForm!:FormGroup;
public constructor(private fb:FormBuilder){

}
ngOnInit():void{
 this.initForm();
}

onSubmit(): void {
  console.log('Form Value:', this.userForm.value);
  console.log('Full Name:', this.userForm.get('fullname')?.value);
}



 initForm() {
    this.userForm = this.fb.group({
      fullname: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z ]+$/)]], // TEXT BOX
      email: ['', [Validators.required, Validators.email]], //TEXT BOX
      password: ['', [Validators.required, Validators.minLength(8)]], //TEXT BOX
      cPassword: ['', Validators.required], //TEXT BOX
      age: ['', [Validators.required, Validators.min(13)]], //TEXT BOX
      dateOfBirth: ['', Validators.required], //DATE PICKER
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]], //TEXT BOX
      gender: ['', Validators.required], //DROP DOWN
      address: ['', Validators.required], //TEXT BOX ,Text Area
      city: ['', Validators.required], //TEXT BOX
      state: ['', Validators.required], //TEXT BOX
      zipCode: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]], //TEXT BOX
      termCondition: [false, Validators.requiredTrue],  // CREATE IN PARENT ONLY
    });
  }

  }