import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-child',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule ],
  templateUrl: './child.component.html'
})
export class ChildComponent {

  @Input() control!: FormControl;
  @Input() label: string = '';
  @Input() placeholder: string = '';

}
