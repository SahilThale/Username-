import { CommonModule } from '@angular/common';
import { Component, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-text-box',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './text-box.component.html',
  styleUrl: './text-box.component.css',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TextBoxComponent),
      multi: true
    }
  ]
})
export class TextBoxComponent implements ControlValueAccessor {


  @Input() label: string = '';
  @Input() inputType: string = 'text';
  @Input() isAstrick: boolean = false;
  @Input() placeholder: string = '';
  @Input() readonly: boolean = false;

  @Input() maxLength: number | null = null;
  @Input() minLength: number | null = null;
  @Input() pattern: string | null = null;

  @Input() errorMessage: string = '';
  @Input() textDecoration: 'upper' | 'lower' | 'none' = 'none';


  value: string = '';
  disabled: boolean = false;

  private onChange: (value: any) => void = () => {};
  private onTouched: () => void = () => {};

  writeValue(value: any): void {
    this.value = value ?? '';
    this.applyTextDecoration();
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }


  onInput(event: Event): void {
    let value = (event.target as HTMLInputElement).value;

    if (this.textDecoration === 'upper') {
      value = value.toUpperCase();
    } else if (this.textDecoration === 'lower') {
      value = value.toLowerCase();
    }

    this.value = value;
    this.onChange(value); 
  }

  onBlur(): void {
    this.onTouched(); 
  }


  private applyTextDecoration(): void {
    if (this.textDecoration === 'upper') {
      this.value = this.value.toUpperCase();
    } else if (this.textDecoration === 'lower') {
      this.value = this.value.toLowerCase();
    }
  }
}
