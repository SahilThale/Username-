import { NgClass, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'app-button',
    standalone: true,
    templateUrl: './button.component.html',
    styleUrls: ['./button.component.css'],
    imports: [NgClass, NgIf]
})
export class ButtonComponent implements OnInit {
  @Input() label: string='';
  @Input() type: string = 'button'; 
  @Input() buttonClass: string=''; 

  @Input() inputId: string = "text";
  @Input() isDisabled:boolean=false;

  @Output() buttonClick: EventEmitter<void> = new EventEmitter<void>();

  onClick() {
   
    this.buttonClick.emit();
  }
  constructor() { }

  ngOnInit(): void {
  }

}
