import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
  import { City, Status, User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  // Replace with your actual .NET Port (check launchSettings.json)
  private apiUrl = 'https://localhost:7123/api/User'; 

  constructor(private http: HttpClient) { }

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  addUser(user: any): Observable<any> {
    return this.http.post(this.apiUrl, user);
  }

// Inside your UserService class...

getAllCities(): Observable<City[]> {
  return this.http.get<City[]>(`${this.apiUrl}/cities`);
}

getAllStatuses(): Observable<Status[]> {
  return this.http.get<Status[]>(`${this.apiUrl}/statuses`);
}
}