export interface City {
  cityId: number;
  cityName: string;
}

export interface Status {
  statusId: number;
  statusName: string;
}

export interface User {
  id?: number; // Optional for new users
  firstName: string;
  lastName: string;
  email: string;
  mobileNumber: string;
  password?: string; // Optional for list view
  gender: string;
  dateOfBirth: string;
  cityId: number;
  statusId: number;
  city?: City;    // Nested object for display
  status?: Status; // Nested object for display
}