import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { UserService } from './services/user';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './user-form.component.html',
  styleUrl: './user-form.component.css'
})
export class UserFormComponent implements OnInit {
  userForm: FormGroup;
  cities: any[] = [];
  statuses: any[] = [];

  constructor(private fb: FormBuilder, private userService: UserService) {
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      gender: ['', Validators.required],
      dateOfBirth: ['', [Validators.required, this.futureDateValidator]],
      cityId: ['', Validators.required],
      statusId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Load dropdowns from your .NET API
    this.userService.getAllCities().subscribe(data => this.cities = data);
    this.userService.getAllStatuses().subscribe(data => this.statuses = data);
  }

  // Custom Validator for Future Dates
  futureDateValidator(control: AbstractControl) {
    const selectedDate = new Date(control.value);
    const today = new Date();
    return selectedDate > today ? { futureDate: true } : null;
  }

  onSubmit() {
    if (this.userForm.valid) {
      this.userService.addUser(this.userForm.value).subscribe({
        next: (res) => alert(res.message),
        error: (err) => alert("Error: " + err.error.message)
      });
    } else {
      this.userForm.markAllAsTouched(); // Trigger red styles for all fields
    }
  }
}