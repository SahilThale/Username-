import { Routes } from '@angular/router';
import { UserList } from './components/user/user-list/user-list';
import { UserForm } from './components/user/user-form/user-form';

export const routes: Routes = [
  { path: '', redirectTo: 'users', pathMatch: 'full' },
  { path: 'users', component: UserList },
  { path: 'add-user', component: UserForm },
  { path: 'edit-user/:id', component: UserForm } // Reuse form for editing
];