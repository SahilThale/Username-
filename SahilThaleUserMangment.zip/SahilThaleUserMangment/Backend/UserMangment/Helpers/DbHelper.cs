using Oracle.ManagedDataAccess.Client;
using Microsoft.Extensions.Configuration;
public class DbHelper
{
    private readonly string _connectionString;

    public DbHelper(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("OracleDbCon");
    }

    public OracleConnection GetConnection()
    {
        return new OracleConnection(_connectionString);
    }
}