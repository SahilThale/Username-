using Oracle.ManagedDataAccess.Client;
using System.Data;

public class UserRepository : IUserRepository
{
    private readonly DbHelper _dbHelper;

    public UserRepository(DbHelper dbHelper)
    {
        _dbHelper = dbHelper;
    }
    
    public User? GetUserById(int id)
{
    User? user = null;

    // Use a verbatim string (@"...") for multi-line SQL queries
    string query = @"
        SELECT u.*, c.CITYNAME, s.STATUSNAME 
        FROM SAHIL_USER u
        INNER JOIN SAHIIL_CITY c  ON u.CITYID = c.CITYID
        INNER JOIN SAHIL_STATUS s ON u.STATUSID = s.STATUSID
        WHERE u.USERID = :p_id AND u.VISIBLE = 1";

    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand(query, conn))
        {
            // IMPORTANT: In direct queries, Oracle uses ':' for parameters, not '@' or 'p_'
            cmd.Parameters.Add("p_id", OracleDbType.Int32).Value = id;

            conn.Open();
            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    user = new User
                    {
                        Id = Convert.ToInt32(reader["USERID"]),
                        FirstName = reader["FIRSTNAME"].ToString() ?? "",
                        LastName = reader["LASTNAME"].ToString() ?? "",
                        Email = reader["EMAIL"].ToString() ?? "",
                        Gender = Convert.ToChar(reader["GENDER"]),
                        DateOfBirth = Convert.ToDateTime(reader["DATEOFBIRTH"]),
                        CityId = Convert.ToInt32(reader["CITYID"]),
                        StatusId = Convert.ToInt32(reader["STATUSID"]),
                        City = new City
                        {
                            CityId = Convert.ToInt32(reader["CITYID"]),
                            CityName = reader["CITYNAME"].ToString() ?? ""
                        },
                        Status = new Status
                        {
                            StatusId = Convert.ToInt32(reader["STATUSID"]),
                            StatusName = reader["STATUSNAME"].ToString() ?? ""
                        }
                    };
                }
            }
        }
    }
    return user;
}
   public IEnumerable<User> GetAllUsers()
    {
        List<User> users = new List<User>();

        // 1. Define the SQL Query with JOINs
        string query = @"
            SELECT u.*, c.CITYNAME, s.STATUSNAME 
            FROM SAHIL_USER u
            INNER JOIN SAHIIL_CITY c  ON u.CITYID = c.CITYID
            INNER JOIN SAHIL_STATUS s ON u.STATUSID = s.STATUSID
            WHERE u.VISIBLE = 1"; // Only fetch users that aren't 'deleted'

        using (var conn = _dbHelper.GetConnection())
        {
            OracleCommand cmd = new OracleCommand(query, conn);
            conn.Open();

            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    // 2. Map the data to the User object
                    var user = new User
                    {
                        Id = Convert.ToInt32(reader["USERID"]),
                        FirstName = reader["FIRSTNAME"].ToString(),
                        LastName = reader["LASTNAME"].ToString(),
                        Email = reader["EMAIL"].ToString(),
                        Password = reader["PASSWORD"].ToString(),
                        Gender = Convert.ToChar(reader["GENDER"]),
                        DateOfBirth = Convert.ToDateTime(reader["DATEOFBIRTH"]),
                        CityId = Convert.ToInt32(reader["CITYID"]),
                        StatusId = Convert.ToInt32(reader["STATUSID"]),
                        
                        // 3. Map the Relationship (Nested Objects)
                        City = new City
                        {
                            CityId = Convert.ToInt32(reader["CITYID"]),
                            CityName = reader["CITYNAME"].ToString()
                        },
                        Status = new Status
                        {
                            StatusId = Convert.ToInt32(reader["STATUSID"]),
                            StatusName = reader["STATUSNAME"].ToString()
                        }
                    };

                    users.Add(user);
                }
            }
        }
        return users;
    }
    
    public string AddUser(User user)
{
    string statusMessage = string.Empty;
    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand("SAHIL_USER_INS", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;
            // CRITICAL: Tells Oracle to match by name, not by the order you add them
            cmd.BindByName = true; 

            cmd.Parameters.Add("p_firstname", OracleDbType.Varchar2).Value = user.FirstName;
            cmd.Parameters.Add("p_lastname", OracleDbType.Varchar2).Value = user.LastName;
            cmd.Parameters.Add("p_email", OracleDbType.Varchar2).Value = user.Email;
            // ADDED THIS:
            cmd.Parameters.Add("p_mobilenumber", OracleDbType.Int64).Value = user.MobileNumber; 
            cmd.Parameters.Add("p_password", OracleDbType.Varchar2).Value = user.Password;
            cmd.Parameters.Add("p_gender", OracleDbType.Char).Value = user.Gender;
            cmd.Parameters.Add("p_dob", OracleDbType.Date).Value = user.DateOfBirth;
            cmd.Parameters.Add("p_cityid", OracleDbType.Int32).Value = user.CityId;
            cmd.Parameters.Add("p_statusid", OracleDbType.Int32).Value = user.StatusId;

            OracleParameter outputParam = new OracleParameter("p_status_msg", OracleDbType.Varchar2, 500);
            outputParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(outputParam);

            try {
                conn.Open();
                cmd.ExecuteNonQuery();
                statusMessage = outputParam.Value.ToString() ?? "No response";
            }
            catch (Exception ex) {
                statusMessage = "DB Error: " + ex.Message;
            }
        }
    }
    return statusMessage;
}

public string DeleteUser(int id)
{
    string statusMessage = string.Empty;

    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand("SAHIL_USER_DEL", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;

            // 1. Pass the User ID to delete
            cmd.Parameters.Add("p_id", OracleDbType.Int32).Value = id;

            // 2. Setup the OUT parameter for the response message
            OracleParameter outputParam = new OracleParameter("p_msg", OracleDbType.Varchar2, 500);
            outputParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(outputParam);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();

                // 3. Get the message from Oracle (e.g., "SUCCESS..." or "ERROR...")
                statusMessage = outputParam.Value.ToString() ?? "No response from database";
            }
            catch (Exception ex)
            {
                statusMessage = $"C# Error: {ex.Message}";
            }
        }
    }
    return statusMessage;
}


public string UpdateUser(User user)
{
    string statusMessage = string.Empty;

    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand("SAHIL_USER_UPT", conn))
        {
            cmd.CommandType = CommandType.StoredProcedure;

            // 1. Pass the User ID (Crucial for UPDATE)
            cmd.Parameters.Add("P_userid", OracleDbType.Int32).Value = user.Id;

            // 2. Pass the updated details
            cmd.Parameters.Add("p_firstname", OracleDbType.Varchar2).Value = user.FirstName;
            cmd.Parameters.Add("p_lastname", OracleDbType.Varchar2).Value = user.LastName;
            cmd.Parameters.Add("p_email", OracleDbType.Varchar2).Value = user.Email;
            cmd.Parameters.Add("p_password", OracleDbType.Varchar2).Value = user.Password;
            cmd.Parameters.Add("p_gender", OracleDbType.Char).Value = user.Gender;
            cmd.Parameters.Add("p_dob", OracleDbType.Date).Value = user.DateOfBirth;
            cmd.Parameters.Add("p_cityid", OracleDbType.Int32).Value = user.CityId;
            cmd.Parameters.Add("p_statusid", OracleDbType.Int32).Value = user.StatusId;

            // 3. Setup the OUT parameter for the response message
            OracleParameter outputParam = new OracleParameter("p_msg", OracleDbType.Varchar2, 500);
            outputParam.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(outputParam);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                statusMessage = outputParam.Value.ToString() ?? "No response from DB";
            }
            catch (Exception ex)
            {
                statusMessage = "C# Error: " + ex.Message;
            }
        }
    }
    return statusMessage;
}



// Get all Cities
public IEnumerable<City> GetAllCities()
{
    var cities = new List<City>();
    string query = "SELECT CITYID, CITYNAME FROM SAHIIL_CITY ORDER BY CITYNAME";

    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand(query, conn))
        {
            conn.Open();
            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    cities.Add(new City
                    {
                        CityId = Convert.ToInt32(reader["CITYID"]),
                        CityName = reader["CITYNAME"].ToString() ?? ""
                    });
                }
            }
        }
    }
    return cities;
}

// Get all Statuses
public IEnumerable<Status> GetAllStatuses()
{
    var statuses = new List<Status>();
    string query = "SELECT STATUSID, STATUSNAME FROM SAHIL_STATUS";

    using (var conn = _dbHelper.GetConnection())
    {
        using (OracleCommand cmd = new OracleCommand(query, conn))
        {
            conn.Open();
            using (OracleDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    statuses.Add(new Status
                    {
                        StatusId = Convert.ToInt32(reader["STATUSID"]),
                        StatusName = reader["STATUSNAME"].ToString() ?? ""
                    });
                }
            }
        }
    }
    return statuses;
}
}