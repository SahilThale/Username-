// using UserMangment.Models;
using System.Collections.Generic;

public interface IUserRepository
{
    string UpdateUser(User user);
    User GetUserById(int id);
    IEnumerable<User> GetAllUsers();
    IEnumerable<City> GetAllCities();
    IEnumerable<Status> GetAllStatuses();
    string DeleteUser(int id);
    string AddUser(User user);
}