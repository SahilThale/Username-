using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/user")]
public class UserController : ControllerBase
{
    private readonly IUserRepository _userRepo;

    public UserController(IUserRepository userRepo)
    {
        _userRepo = userRepo;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        try
        {
            var users = _userRepo.GetAllUsers();
            return Ok(users);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }


    [HttpPost]
    public IActionResult CreateUser(User user)
    {
        var result = _userRepo.AddUser(user);

        if (result.StartsWith("SUCCESS"))
        {
            return Ok(new { message = result });
        }
        else
        {
            return BadRequest(new { message = result });
        }
    }



    [HttpDelete("{id}")] // URL: DELETE api/user/5
public IActionResult DeleteUser(int id)
{
    var result = _userRepo.DeleteUser(id);

    // If the message starts with SUCCESS, return 200 OK
    if (result.StartsWith("SUCCESS"))
    {
        return Ok(new { message = result });
    }
    
    // Otherwise, return 400 Bad Request (for ID not found or already deleted)
    return BadRequest(new { message = result });
}


[HttpPut("{id}")] // URL: PUT api/user/5
public IActionResult UpdateUser(int id, User user)
{
    // Ensure the ID in the URL matches the ID in the object
    user.Id = id;

    var result = _userRepo.UpdateUser(user);

    if (result.StartsWith("SUCCESS"))
    {
        return Ok(new { message = result });
    }
    else
    {
        return BadRequest(new { message = result });
    }
}

[HttpGet("{id}")]
public IActionResult GetById(int id)
{
    var user = _userRepo.GetUserById(id);
    if (user == null) return NotFound();
    return Ok(user);
}

[HttpGet("cities")] // URL: api/user/cities
public IActionResult GetCities()
{
    return Ok(_userRepo.GetAllCities());
}

[HttpGet("statuses")] // URL: api/user/statuses
public IActionResult GetStatuses()
{
    return Ok(_userRepo.GetAllStatuses());
}

}