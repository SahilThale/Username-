public class User
{
    public int? Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Email { get; set; }
    public long MobileNumber { get; set; }
    public string Password { get; set; }
    public char Gender { get; set; }
    public DateTime DateOfBirth { get; set; }
    public int CityId { get; set; }
    public int StatusId { get; set; }

    public City? City { get; set; }
    public Status? Status { get; set; }
}