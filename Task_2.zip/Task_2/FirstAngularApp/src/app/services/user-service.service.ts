import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/User.model';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http:HttpClient) { }

  private api="https://localhost:7174";
  testApi():Observable<string>{
    return this.http.get(this.api,{ responseType: 'text' });
  }

 // user-service.service.ts

saveUser(u: User): Observable<any> { // Changed string to any because we get an object
  return this.http.post(this.api+"/api/user", u, { 
    withCredentials: true 
    // REMOVED responseType: 'text' because the server now sends JSON
  });
}

getUser(): Observable<User[]> {
  return this.http.get<User[]>(this.api+"/api/user", { withCredentials: true });
}

// user-service.service.ts

getUserById(id: number): Observable<User> {
  return this.http.get<User>(`${this.api}/api/user/${id}`, { withCredentials: true });
}
updateUser(id: number, u: User): Observable<any> {
  return this.http.post(`${this.api}/update/${id}`, u, { withCredentials: true });
}

deleteUser(id: number): Observable<any> {
    return this.http.post(`${this.api}/delete/${id}`, id,{ withCredentials: true });
}
}
