import { Component, OnInit } from '@angular/core';
import { NgFor, NgIf, NgClass } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
  ValidationErrors
} from '@angular/forms';
import { UserServiceService } from '../services/user-service.service';
import { User } from '../models/User.model';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [ReactiveFormsModule, NgFor, NgIf, NgClass],
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {
  userForm!: FormGroup;
  userList: User[] = [];
  genders: string[] = ['Male', 'Female', 'Other'];
  
  // CRUD State variables
  isEditMode: boolean = false;
  editingUserId: number | null = null;

  constructor(private fb: FormBuilder, private service: UserServiceService) { }

  ngOnInit(): void {
    this.initForm();
    this.fetchUsers();
  }

  initForm() {
    this.userForm = this.fb.group({
      fullname: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      cPassword: ['', Validators.required],
      age: ['', [Validators.required, Validators.min(18)]],
      phone: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      gender: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipCode: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      termCondition: [false, Validators.requiredTrue],
    }, {
      validators: confirmPasswordValidator
    });
  }

  fetchUsers() {
    this.service.getUser().subscribe({
      next: (data) => {
        this.userList = data;
        console.log('Users loaded:', data);
      },
      error: (err) => console.error('Error fetching users', err)
    });
  }

  onSubmit() {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      alert('Please fill all required fields correctly.');
      return;
    }

    const formValue = this.userForm.value;
    const userData: User = {
      fullName: formValue.fullname,
      email: formValue.email,
      password: formValue.password,
      age: formValue.age,
      phone: formValue.phone,
      gender: formValue.gender,
      address: formValue.address,
      city: formValue.city,
      state: formValue.state,
      zipCode: formValue.zipCode
    };

    if (this.isEditMode && this.editingUserId) {
      // UPDATE
      this.service.updateUser(this.editingUserId, userData).subscribe({
        next: (res) => {
          alert(res.message);
          this.cancelEdit();
          this.fetchUsers();
        },
        error: (err) => console.error('Update failed', err)
      });
    } else {
      // CREATE
      this.service.saveUser(userData).subscribe({
        next: (res) => {
          alert(res.message);
          this.userForm.reset();
          this.fetchUsers();
        },
        error: (err) => alert(err.error?.message || 'Save failed')
      });
    }
  }

  onEdit(id: number) {
    // Fetch individual user data from server before editing
    this.service.getUserById(id).subscribe({
      next: (user) => {
        this.isEditMode = true;
        this.editingUserId = user.id!;
        
        this.userForm.patchValue({
          fullname: user.fullName,
          email: user.email,
          password: user.password,
          cPassword: user.password,
          age: user.age,
          phone: user.phone,
          gender: user.gender,
          address: user.address,
          city: user.city,
          state: user.state,
          zipCode: user.zipCode,
          termCondition: true
        });
        window.scrollTo(0, 0);
      },
      error: (err) => alert("User not found or session expired")
    });
  }

  onDelete(id: number) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.service.deleteUser(id).subscribe({
        next: (res) => {
          alert(res.message);
          this.fetchUsers();
        }
      });
    }
  }

  cancelEdit() {
    this.isEditMode = false;
    this.editingUserId = null;
    this.userForm.reset();
  }
}

// Validator Function
function confirmPasswordValidator(group: FormGroup): ValidationErrors | null {
  const password = group.get('password')?.value;
  const cPassword = group.get('cPassword')?.value;
  return password === cPassword ? null : { passwordMismatch: true };
}