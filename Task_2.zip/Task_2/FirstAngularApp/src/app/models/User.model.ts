export interface User {
    id?: number;
    fullName: string; 
    email: string;
    password: string;
    age: number;
    phone: number;
    gender: string;
    address: string;
    city: string;
    state: string;
    zipCode: number;
}