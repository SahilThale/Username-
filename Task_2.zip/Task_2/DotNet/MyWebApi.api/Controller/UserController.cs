using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.Json;

namespace MYWEBAPI.API.Controllers
{
    [ApiController]
    [Route("api/user")]
    public class UserController : ControllerBase
    {
        [HttpPost]
        public IActionResult SaveUser(User u)
        {
            var data = HttpContext.Session.GetString("Users");
            List<User> userList = !string.IsNullOrEmpty(data)
                ? JsonSerializer.Deserialize<List<User>>(data)
                : new List<User>();

            // 1. CHECK IF USER ALREADY EXISTS (by Email)
            if (userList.Any(x => x.Email.ToLower() == u.Email.ToLower()))
            {
                return BadRequest(new { message = "User with this email already exists!" });
            }

            // 2. FIND THE HIGHEST ID
            // If list is empty, start at 0, otherwise find the Max ID
            int lastId = userList.Count > 0 ? userList.Max(x => x.Id ?? 0) : 0;
            u.Id = lastId + 1;

            // 3. ADD AND SAVE
            userList.Add(u);
            HttpContext.Session.SetString("Users", JsonSerializer.Serialize(userList));

            return Ok(new { message = "User saved successfully", id = u.Id });
        }

        [HttpGet]
        public IActionResult Get()
        {

            var data = HttpContext.Session.GetString("Users");

            if (string.IsNullOrEmpty(data))
            {
                return Ok(new List<User>());
            }

            var userList = JsonSerializer.Deserialize<List<User>>(data);
            return Ok(userList);
        }


        [HttpPost("/update/{id}")]
        public IActionResult UpdateUser(int id, User updatedData)
        {
            var data = HttpContext.Session.GetString("Users");
            if (string.IsNullOrEmpty(data)) return NotFound();

            var userList = JsonSerializer.Deserialize<List<User>>(data);
            var existingUser = userList.FirstOrDefault(x => x.Id == id);

            if (existingUser == null) return NotFound();

            existingUser.FullName = updatedData.FullName;
            existingUser.Email = updatedData.Email;
            existingUser.Password = updatedData.Password;
            existingUser.Age = updatedData.Age;
            existingUser.Phone = updatedData.Phone;
            existingUser.Gender = updatedData.Gender;
            existingUser.Address = updatedData.Address;
            existingUser.City = updatedData.City;
            existingUser.State = updatedData.State;
            existingUser.ZipCode = updatedData.ZipCode;

            // ... update other fields ...

            // Re-save
            HttpContext.Session.SetString("Users", JsonSerializer.Serialize(userList));
            return Ok(new { message = "User updated successfully" });
        }
        [HttpPost("/delete/{id}")]
        public IActionResult DeleteUser(int id)
        {
            var data = HttpContext.Session.GetString("Users");
            if (string.IsNullOrEmpty(data)) return NotFound();

            var userList = JsonSerializer.Deserialize<List<User>>(data);

            // Find the user
            var userToDelete = userList.FirstOrDefault(x => x.Id == id);
            if (userToDelete == null) return NotFound(new { message = "User not found" });

            // Remove and Re-save
            userList.Remove(userToDelete);
            HttpContext.Session.SetString("Users", JsonSerializer.Serialize(userList));

            return Ok(new { message = "User deleted successfully" });
        }

        [HttpGet("{id}")]
public IActionResult GetById(int id)
{
    var data = HttpContext.Session.GetString("Users");
    if (string.IsNullOrEmpty(data)) return NotFound();

    var userList = JsonSerializer.Deserialize<List<User>>(data);
    
    // Find the specific user
    var user = userList.FirstOrDefault(x => x.Id == id);
    
    if (user == null) 
        return NotFound(new { message = "User not found" });

    return Ok(user);
}
    }

}
