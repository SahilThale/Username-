var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(o =>
{
    o.IdleTimeout=TimeSpan.FromMinutes(10);
    o.Cookie.IsEssential=true;
    o.Cookie.HttpOnly=true;

    o.Cookie.SameSite = SameSiteMode.None; // Allows the cookie to be sent across origins
    o.Cookie.SecurePolicy = CookieSecurePolicy.Always; // Required if SameSite is None
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("Test", policy =>
    {
        policy.WithOrigins("http://localhost:4200")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("Test"); 
app.UseHttpsRedirection();
app.UseSession();
app.MapControllers();
app.MapGet("/", () =>
{
    return Results.Ok("Minimal api is working");
});

app.Run();
